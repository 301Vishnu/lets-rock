// Setting time interval

// Generating random color

// Changing background color

// Changing background text